package com.customer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String details = request.getParameter("details");
        double price = Double.parseDouble(request.getParameter("price"));
        double rating = Double.parseDouble(request.getParameter("rating"));
        String imagePath = request.getParameter("imagePath");
        
        boolean isSuccess = ProductDBUtil.insertProduct(name, details, price, rating, imagePath);
        
        if(isSuccess) {
            response.sendRedirect("ProductServlet");
        } else {
            RequestDispatcher dispatcher = request.getRequestDispatcher("addproduct.jsp");
            dispatcher.forward(request, response);
        }
    }
}