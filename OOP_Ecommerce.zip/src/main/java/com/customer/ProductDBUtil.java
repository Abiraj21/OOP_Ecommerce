package com.customer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductDBUtil {
    
    private static Connection con = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;
    
    // Add new product to database
    public static boolean insertProduct(String name, String details, double price, double rating, String imagePath) {
        boolean isSuccess = false;
        
        try {
            con = DBConnect.getConnection();
            stmt = con.createStatement();
            String sql = "INSERT INTO product VALUES (0, '"+name+"', '"+details+"', "+price+", "+rating+", '"+imagePath+"')";
            int rs = stmt.executeUpdate(sql);
            
            if(rs > 0) {
                isSuccess = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return isSuccess;
    }
    
    // Update existing product
    public static boolean updateProduct(String id, String name, String details, double price, double rating, String imagePath) {
        boolean isSuccess = false;
        
        try {
            con = DBConnect.getConnection();
            stmt = con.createStatement();
            String sql = "UPDATE product SET name='"+name+"', details='"+details+"', price="+price+", rating="+rating+", imagePath='"+imagePath+"' WHERE id="+id;
            int rs = stmt.executeUpdate(sql);
            
            if(rs > 0) {
                isSuccess = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return isSuccess;
    }
    
    // Delete product by ID
    public static boolean deleteProduct(String id) {
        boolean isSuccess = false;
        
        try {
            con = DBConnect.getConnection();
            stmt = con.createStatement();
            String sql = "DELETE FROM product WHERE id="+id;
            int rs = stmt.executeUpdate(sql);
            
            if(rs > 0) {
                isSuccess = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return isSuccess;
    }
    
    // Get all products
    public static List<Product> getAllProducts() {
        ArrayList<Product> products = new ArrayList<>();
        
        try {
            con = DBConnect.getConnection();
            stmt = con.createStatement();
            String sql = "SELECT * FROM product";
            rs = stmt.executeQuery(sql);
            
            while(rs.next()) {
                int id = rs.getInt(1);
                String name = rs.getString(2);
                String details = rs.getString(3);
                double price = rs.getDouble(4);
                double rating = rs.getDouble(5);
                String imagePath = rs.getString(6);
                
                Product product = new Product(id, name, details, price, rating, imagePath);
                products.add(product);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return products;
    }
    
    // Get single product by ID
    public static Product getProductById(String id) {
        Product product = null;
        
        try {
            con = DBConnect.getConnection();
            stmt = con.createStatement();
            String sql = "SELECT * FROM product WHERE id="+id;
            rs = stmt.executeQuery(sql);
            
            if(rs.next()) {
                int pid = rs.getInt(1);
                String name = rs.getString(2);
                String details = rs.getString(3);
                double price = rs.getDouble(4);
                double rating = rs.getDouble(5);
                String imagePath = rs.getString(6);
                
                product = new Product(pid, name, details, price, rating, imagePath);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return product;
    }
}