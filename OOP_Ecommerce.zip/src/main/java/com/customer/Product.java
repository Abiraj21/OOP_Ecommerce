package com.customer;

public class Product {
    private int id;
    private String name;
    private String details;
    private double price;
    private double rating;
    private String imagePath;
    
    public Product(int id, String name, String details, double price, double rating, String imagePath) {
        this.id = id;
        this.name = name;
        this.details = details;
        this.price = price;
        this.rating = rating;
        this.imagePath = imagePath;
    }

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDetails() {
		return details;
	}

	public double getPrice() {
		return price;
	}

	public double getRating() {
		return rating;
	}

	public String getImagePath() {
		return imagePath;
	}
    
}